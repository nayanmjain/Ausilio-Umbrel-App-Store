-- This file should undo anything in `up.sql`

DROP TABLE blocklist_lookup;
